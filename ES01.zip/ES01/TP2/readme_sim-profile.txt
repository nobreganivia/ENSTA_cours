
# Afin de lancer la simulation simplesclar, il faut avoir compilé
# votre application avec le cross compilateur sslittle-na-sstrix-gcc

#Chemin vers l'executable sim-profile
SIM_PROFILE=/usr/ensta/pack/simplescalar-3v0d/simplesim-3.0/sim-profile






